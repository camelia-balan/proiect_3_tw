function AfisareExperienta(props) {
    let {item} =props
        return (
       
       <div>
         Punct plecare {item.punctPlecare}. Punct sosire { item.punctSosire}. Mijloc transport {item.mijlocTransport}
          Ora plecare {item.oraPlecare}
          Durata calatoriei {item.durataCalatorie}
          Grad aglomerare {item.gradAglomerare}
          Observatii {item.observatii}
          Nivel de satisfactie {item.nivelSatisfactie}
        </div>
    )
}
export default AfisareExperienta;