import './App.css';
import Menu from './components/Menu'
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Footer from './components/Footer';
import SignUp from './components/SignUp';
import Experienta from './components/Experienta';
import ListaExperienta from './ListaExperiente';
import Login from './components/Login';
import Search from './components/Search';
function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Menu />
      <Routes>
        <Route path ="/user" element={<h1>User</h1>}></Route>
        <Route path="/search" element ={<Search/>}></Route>
        <Route path="/signup" element={<SignUp/>}></Route>
        <Route path="/exp" element = {<Experienta/>}></Route>
        <Route path="/login" element = {<Login/>}></Route>
      </Routes>
      </BrowserRouter>
      <Footer/>
    </div>
  );
}

export default App;
