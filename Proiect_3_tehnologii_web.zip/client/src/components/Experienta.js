import React, {useState,useRef} from 'react'
import istoric from '../ExperientaNoua';

const Experienta =() => {
    const [punctPlecare, setPunctPlecare] = useState("");
    const [punctSosire,setPunctSosire] = useState("");
    const [mijlocTransport,setMijlocTransport] = useState("");
    const [oraPlecare,setOraPlecare] = useState("");
    const [durataCalatorie,setDurataCalatorie] = useState("");
    const [gradAglomerare, setGradAglomerare] = useState("");
    const [observatii,setObservatii] = useState("");
    const [nivelSatisfactie, setNivelSatisfactie] = useState("");
   
    const refPunctPlecare = useRef(null)
    const refPunctSosire=useRef(null)
    const refMijlocTransport=useRef(null)
    const refOraPlecare=useRef(null)
    const refDurataCalatorie=useRef(null)
    const refGradAglomerare = useRef(null)
    const refObservatii = useRef(null)
    const refNivelSatisfactie = useRef(null)
    
    const add = (inf) => {
        inf.punctPlecare=punctPlecare;
        inf.punctSosire=punctSosire;
        inf.mijlocTransport=mijlocTransport;
        inf.oraPlecare=oraPlecare;
        inf.durataCalatorie=durataCalatorie;
        inf.gradAglomerare=gradAglomerare;
        inf.observatii=observatii;
        inf.nivelSatisfactie=nivelSatisfactie;
        istoric.addExperienta(inf)  
        refPunctPlecare.current.value="";
        refPunctSosire.current.value="";
        refMijlocTransport.current.value="";
        refOraPlecare.current.value="";
        refDurataCalatorie.current.value="";
        refGradAglomerare.current.value="";
        refObservatii.current.value="";
        refNivelSatisfactie.current.value="";
        document.getElementById("afisare").innerHTML+= "- Punct plecare: "+punctPlecare+" | Punct sosire: "+punctSosire+" | Mijloc de transport: "+
        mijlocTransport+" | Ora plecare: "+oraPlecare+" | Durata calatorie: "+durataCalatorie+" | Grad aglomerare: "+gradAglomerare+" | Observatii: "+
        observatii+" | Nivel satisfactie: "+nivelSatisfactie+"<br>";
      

    }
    return (
        <div className='exper'>
            <h1>Impartaseste experienta ta!</h1>
            <label htmlFor='punctPlecare' margin-left = "7px">Punct plecare:</label>
            <input className="inputExp" type='text' ref={refPunctPlecare} placeholder="Completeaza..."  onChange={(inf) => setPunctPlecare(inf.target.value)}  />
            <span></span>          
            <label htmlFor='punctSosire'margin-left = "7px"><strong></strong>Punct sosire:</label>
            <input className="inputExp" type='text' ref={refPunctSosire} placeholder="Completeaza..."  onChange={(inf) => setPunctSosire(inf.target.value)}/>
            <label htmlFor='mijlocTransport'margin-left = "7px"><strong></strong>Mijloc transport:</label>
            <input className="inputExp" type='text' ref={refMijlocTransport} placeholder="Completeaza..."  onChange={(inf) => setMijlocTransport(inf.target.value)}/>
            <label htmlFor='oraPlecare'margin-left = "7px">Ora plecare:</label>
            <input className="inputExp" type='text' ref={refOraPlecare} placeholder="Completeaza..."  onChange={(inf) => setOraPlecare(inf.target.value)}/>
            <label htmlFor='durataCalatorie'>Durata calatorie:</label>
            <input className="inputExp" type='text' ref={refDurataCalatorie} placeholder="Completeaza..." onChange={(inf) => setDurataCalatorie(inf.target.value)}/>
            <label htmlFor='gradAglomerare'>Grad aglomerare (1-5 unde 1 - liber si 5 - foarte aglomerat):</label>
            <input className="inputExp" type='text' ref={refGradAglomerare} placeholder="Completeaza..." onChange={(inf) => setGradAglomerare(inf.target.value)}/>
            <label htmlFor='observatii'>Observatii:</label>
            <input className="inputExp" type='text' ref={refObservatii} placeholder="Completeaza..." onChange={(inf) => setObservatii(inf.target.value)}/>
            <label htmlFor='Nivel satisfactie'>Nivel satisfactie:</label>
            <input className="inputExp" type='text' ref={refNivelSatisfactie}  placeholder="Completeaza..." onChange={(inf) => setNivelSatisfactie(inf.target.value)}/>
            <input  className="button" type='button' value="Adauga experienta" onClick={add} ></input>
            <p id="afisare"></p>
        </div>
    )

}
export default Experienta