import React, { useState } from "react";
const Search =() => {
    
    const dataFromDatabase = [
    {id: 1,PunctPlecare: "Crangasi",PunctSosire:"Gara de nord",MijlocTransport:"Metrou",OraPlecare: "10pm",DurataCalatorie:"5min",GradAglomerare:1, Observatii:"nu sunt observatii",NivelSatisfactie:"acceptabil" },
    {id: 2, PunctPlecare: "Piata Romana",PunctSosire:"Eroii revolutiei",MijlocTransport:"STB",OraPlecare: "10pm",DurataCalatorie:"13min",GradAglomerare:1, Observatii:"aglomerat",NivelSatisfactie:"acceptabil"},
    {id: 3, PunctPlecare:"Berceni", PunctSosire: "Tineretului",MijlocTransport:"STB",OraPlecare: "10pm",DurataCalatorie:"20min",GradAglomerare:1, Observatii:"trafic blocat",NivelSatisfactie:"acceptabil"},
    {id: 4, PunctPlecare:"Piata Sudului", PunctSosire: "Crangasi",MijlocTransport:"Tramvai",OraPlecare: "10pm",DurataCalatorie:"20min",GradAglomerare:1, Observatii:"nu sunt observatii",NivelSatisfactie:"acceptabil"},
    {id: 5, PunctPlecare:"Constantin Brancoveanu", PunctSosire: "Piata Romana",MijlocTransport:"Metrou",OraPlecare: "10pm",DurataCalatorie:"23min",GradAglomerare:1, Observatii:"aglomerat",NivelSatisfactie:"acceptabil"},
    {id: 6, PunctPlecare:"Piata Victoriei", PunctSosire: "Tineretului",MijlocTransport:"STB",OraPlecare: "10pm",DurataCalatorie:"23min",GradAglomerare:1, Observatii:"nu sunt observatii",NivelSatisfactie:"acceptabil"},
    {id: 7, PunctPlecare:"Timpuri noi", PunctSosire: "Berceni",MijlocTransport:"Metrou",OraPlecare: "10pm",DurataCalatorie:"33min",GradAglomerare:1, Observatii:"nu sunt observatii",NivelSatisfactie:"acceptabil"},
    {id: 8, PunctPlecare:"Universitate", PunctSosire: "Piata Victoriei",MijlocTransport:"Metrou",OraPlecare: "10pm",DurataCalatorie:"23min",GradAglomerare:1, Observatii:"aglomerat",NivelSatisfactie:"acceptabil"},
    {id: 9, PunctPlecare:"Berceni", PunctSosire: "Piata Romana",MijlocTransport:"Metrou",OraPlecare: "10pm",DurataCalatorie:"13min",GradAglomerare:1, Observatii:"nu sunt observatii",NivelSatisfactie:"acceptabil"},
    {id: 10, PunctPlecare:"Crangasi", PunctSosire: "Tineretului",MijlocTransport:"Metrou",OraPlecare: "10pm",DurataCalatorie:"6min",GradAglomerare:1, Observatii:"nu sunt observatii",NivelSatisfactie:"acceptabil"},
    {id: 11, PunctPlecare:"Piata Victoriei", PunctSosire: "Tineretului",MijlocTransport:"Metrou",OraPlecare: "10pm",DurataCalatorie:"23min",GradAglomerare:1, Observatii:"nu sunt observatii",NivelSatisfactie:"acceptabil"}
    
    ]
    const [data,setData] =useState(dataFromDatabase)
    
    const filterData = e => {
        const search = e.target.value.toLowerCase()
        const filteredData = dataFromDatabase.filter(data => data.PunctPlecare.toLowerCase().includes(search))
  

        setData(filteredData)
    }
    return (
        <div className="search">
          <input className="search_bar" type="text"  onChange={(e) => filterData(e)}/>
       <button className="search_btn">Search</button>
       <ul>
        {data.map(data=> {
            return<li key={data.id}>{data.PunctPlecare} || {data.PunctSosire} || {data.MijlocTransport} || {data.OraPlecare} || {data.DurataCalatorie} || {data.GradAglomerare} || {data.Observatii} || {data.NivelSatisfactie}</li>
        })}
       </ul>
        </div>


    )
}
export default Search;