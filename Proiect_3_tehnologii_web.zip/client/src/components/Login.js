import React, {useRef,useState} from 'react'

const Login =() => {
    
 
    const [email,setEmail] = useState("");
    const [parola,setParola] =useState("");
    const collectData=() => {
        console.warn(email,parola)
    }
  
    return (
        <div className="login">
            <h1> Bine ai venit!</h1>
            <input className="inputLog" type="text" placeholder="Email"value={email} onChange={(e)=>setEmail(e.target.value)}/>
            <input className="inputLog" type="password" placeholder="Parola"value={parola} onChange={(e)=>setParola(e.target.value)}/>
            <input onClick={collectData} className="login_btn" type='button' value="Conectare" ></input>
        </div>


    )
}
export default Login;