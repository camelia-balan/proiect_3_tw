import React, {useRef,useState} from 'react'

const SignUp =() => {
    const [nume,setName] = useState("");
    const [prenume,setPrenume] = useState("")
    const [email,setEmail] = useState("");
    const [parola,setParola] =useState("");
    const collectData=() => {
        console.warn(nume,prenume,email,parola)
        
    }
  
    return (
        <div className="signup">
            <form action="user">
            <h1> Creaza-ti cont</h1>
            <input className="input" type="text" placeholder="Nume" value={nume} onChange={(e)=>setName(e.target.value)}/>
            <input className="input" type="text" placeholder="Prenume"value={prenume} onChange={(e)=>setPrenume(e.target.value)}/>
            <input className="input" type="text" placeholder="Email"value={email} onChange={(e)=>setEmail(e.target.value)}/>
            <input className="input" type="password" placeholder="Parola"value={parola} onChange={(e)=>setParola(e.target.value)}/>
            <input onClick={collectData} className="signup_btn" type='submit' value="Inregistreaza-te" ></input>
            </form>
        </div>
    )
}
export default SignUp;