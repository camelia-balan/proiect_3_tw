import { useEffect, useState } from 'react'
import istoric from './ExperientaNoua'
import AfisareExperienta from './AfisareExperienta'
import Experienta from './components/Experienta'

function ListaExperienta () {
	const [experiente, setExperiente] = useState([])

	useEffect(() => {
		setExperiente(istoric.getExperiente())
		istoric.emitter.addListener('UPDATE', () => {
			setExperiente(istoric.getExperiente())
		})
	}, [])
	
	return (
		<div>				 
			{
				experiente.map((e, i) => 
					<AfisareExperienta item={e} key={i} />
				)
			}
		</div>
	)
}

export default ListaExperienta
