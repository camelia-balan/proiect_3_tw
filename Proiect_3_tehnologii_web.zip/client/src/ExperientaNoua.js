import { EventEmitter} from 'fbemitter'

class ExperientaNoua {
    constructor() {
        this.experiente=[{
            punctPlecare: "Piata Romana",
            punctSosire: "Aparatorii Patriei",
            mijlocTransport: "Metrou",
            oraPlecare:"15:00",
            durataCalatorie:30,
            gradAglomerare:3,
            observatii: "Aglomerat",
            nivelSatisfactie:"satisfacator"
        }]
        this.emitter = new EventEmitter()
    }
    addExperienta(e)
    {
        let maxId=this.experiente.map((e) => e.id).reduce((a,e) => a > e ? a:e,1)
        e.id = maxId + 1 
        this.experiente=[...this.experiente,e]
        this.emitter.emit('UPDATE')
	}
	getExperiente(){
		return this.experiente
	}
}

const istoric = new ExperientaNoua()

export default istoric;